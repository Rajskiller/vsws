#include <stdio.h>
#include<stdlib.h>

int main(void){

    int l1=0,l2=0,l3=0;
    char cha;
    scanf("%c",&cha);

    if (cha =='a')
    {
        l1++;
        l2=0;
        l3=0;printf("%d", l1);
    }
    else if(cha == 's')
    {
        l1=0;
        l2=2;
        l3=0;
        printf("%d",l2);
    }
    else if (cha=='d')
    {
        l1=0;
        l2=0;
        l3=3;
        printf("%d",l3);
    }

}